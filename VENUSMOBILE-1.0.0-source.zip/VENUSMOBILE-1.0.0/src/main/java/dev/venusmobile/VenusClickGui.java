package dev.venusmobile;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public final class VenusClickGui extends Screen {
    private static final int PURPLE = 0xFFB44CFF;
    private static final int RED = 0xFFFF315A;
    private static final int GREEN = 0xFF35E68A;
    private static final int PANEL = 0xE8100B1A;
    private static final int PANEL_ALT = 0xF0181024;

    private final List<String> categories = List.of(
            "Combat", "Visuals", "Movement", "Player", "World", "Misc", "Configs"
    );
    private final List<String> visualModules = List.of(
            "PlayerESP (visual demo)", "NameTags", "HealthBar", "Distance",
            "Tracers (visual demo)", "PotionHUD", "FPS", "Coordinates"
    );
    private final List<Boolean> enabled = new ArrayList<>();
    private int selectedCategory = 1;
    private int theme = 0;

    public VenusClickGui() {
        super(Text.literal("VENUSMOBILE"));
        for (int i = 0; i < visualModules.size(); i++) enabled.add(false);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int accent() {
        return switch (theme) {
            case 1 -> RED;
            case 2 -> GREEN;
            default -> PURPLE;
        };
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int accent = accent();
        int cx = width / 2;
        int panelW = Math.min(720, width - 24);
        int panelH = Math.min(390, height - 28);
        int left = cx - panelW / 2;
        int top = height / 2 - panelH / 2;

        context.fill(0, 0, width, height, 0x6605000B);

        // Main frame and title bar
        context.fill(left - 2, top - 2, left + panelW + 2, top + panelH + 2, accent);
        context.fill(left, top, left + panelW, top + panelH, PANEL);
        context.fill(left, top, left + panelW, top + 48, 0xF51A1028);
        context.drawText(textRenderer, Text.literal("♥"), left + 18, top + 8, RED, true);
        context.drawText(textRenderer, Text.literal("VENUSMOBILE"), left + 38, top + 9, PURPLE, true);
        context.drawText(textRenderer, Text.literal("v1.0.0  •  1.21.4 FABRIC"), left + 185, top + 12, 0xFFD8C8EA, false);
        context.drawText(textRenderer, Text.literal("Right Shift / ESC"), left + panelW - 130, top + 12, 0xFFBBAACB, false);

        // Sidebar
        int sideX = left + 12;
        int sideY = top + 60;
        int sideW = 142;
        context.fill(sideX, sideY, sideX + sideW, top + panelH - 14, PANEL_ALT);
        for (int i = 0; i < categories.size(); i++) {
            int y = sideY + 8 + i * 39;
            boolean selected = i == selectedCategory;
            if (selected) {
                context.fill(sideX + 5, y - 4, sideX + sideW - 5, y + 27, 0xAA5A168F);
                context.fill(sideX + 5, y - 4, sideX + 8, y + 27, accent);
            }
            context.drawText(textRenderer, Text.literal(categories.get(i)), sideX + 16, y + 5,
                    selected ? 0xFFFFFFFF : 0xFFD7C8E8, selected);
        }

        // Content panel
        int contentX = sideX + sideW + 14;
        int contentY = sideY;
        int contentW = left + panelW - 14 - contentX;
        context.fill(contentX, contentY, contentX + contentW, top + panelH - 14, PANEL_ALT);
        String heading = categories.get(selectedCategory);
        context.drawText(textRenderer, Text.literal(heading), contentX + 14, contentY + 12, accent, true);

        if (selectedCategory == 1) {
            int rowY = contentY + 42;
            for (int i = 0; i < visualModules.size(); i++) {
                int col = i / 4;
                int row = i % 4;
                int x = contentX + 12 + col * (contentW / 2);
                int y = rowY + row * 56;
                int cardW = contentW / 2 - 18;
                context.fill(x, y, x + cardW, y + 45, 0xFF21172E);
                context.drawText(textRenderer, Text.literal(visualModules.get(i)), x + 9, y + 8, 0xFFE9DDF4, false);
                int toggleColor = enabled.get(i) ? accent : 0xFF554B60;
                context.fill(x + cardW - 35, y + 8, x + cardW - 10, y + 22, toggleColor);
                context.fill(x + cardW - (enabled.get(i) ? 18 : 33), y + 10,
                        x + cardW - (enabled.get(i) ? 12 : 27), y + 20, 0xFFFFFFFF);
                context.drawText(textRenderer, Text.literal(enabled.get(i) ? "ON" : "OFF"),
                        x + 9, y + 27, enabled.get(i) ? accent : 0xFF998DA5, false);
            }
            context.drawText(textRenderer,
                    Text.literal("Visual overlays are client-side; respect server rules."),
                    contentX + 14, top + panelH - 34, 0xFFBBAACB, false);
        } else {
            context.drawText(textRenderer, Text.literal("Coming in a later update."),
                    contentX + 14, contentY + 48, 0xFFD7C8E8, false);
            context.drawText(textRenderer, Text.literal("This first build focuses on the GUI and visual HUD foundation."),
                    contentX + 14, contentY + 70, 0xFFBBAACB, false);
        }

        // Footer and theme cycle
        context.drawText(textRenderer, Text.literal("THEME"), left + 18, top + panelH - 29, 0xFFD8C8EA, false);
        String themeName = switch (theme) { case 1 -> "RED"; case 2 -> "GREEN"; default -> "PURPLE"; };
        context.fill(left + 72, top + panelH - 36, left + 150, top + panelH - 16, accent);
        context.drawText(textRenderer, Text.literal(themeName), left + 89, top + panelH - 30, 0xFFFFFFFF, true);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int panelW = Math.min(720, width - 24);
        int panelH = Math.min(390, height - 28);
        int left = width / 2 - panelW / 2;
        int top = height / 2 - panelH / 2;
        int sideX = left + 12;
        int sideY = top + 60;
        int sideW = 142;

        if (mouseX >= sideX && mouseX <= sideX + sideW) {
            for (int i = 0; i < categories.size(); i++) {
                int y = sideY + 4 + i * 39;
                if (mouseY >= y && mouseY <= y + 31) {
                    selectedCategory = i;
                    return true;
                }
            }
        }

        if (selectedCategory == 1) {
            int contentX = sideX + sideW + 14;
            int contentY = sideY;
            int contentW = left + panelW - 14 - contentX;
            int rowY = contentY + 42;
            for (int i = 0; i < visualModules.size(); i++) {
                int col = i / 4;
                int row = i % 4;
                int x = contentX + 12 + col * (contentW / 2);
                int y = rowY + row * 56;
                int cardW = contentW / 2 - 18;
                if (mouseX >= x && mouseX <= x + cardW && mouseY >= y && mouseY <= y + 45) {
                    enabled.set(i, !enabled.get(i));
                    return true;
                }
            }
        }

        if (mouseX >= left + 72 && mouseX <= left + 150
                && mouseY >= top + panelH - 36 && mouseY <= top + panelH - 16) {
            theme = (theme + 1) % 3;
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
}
