# VENUSMOBILE 1.0.0 — Minecraft 1.21.4 Fabric

This is the first source-code starter for a shared client-side Fabric mod intended for Windows and Android launchers that support Fabric (including compatible PojavLauncher setups).

## Included in this starter
- Right Shift opens/closes the ClickGUI.
- English interface.
- Purple / red / green accent theme cycle.
- Categories: Combat, Visuals, Movement, Player, World, Misc, Configs.
- Clickable Visuals demo toggles for PlayerESP (visual demo), NameTags, HealthBar, Distance, Tracers (visual demo), PotionHUD, FPS and Coordinates.

**Important:** the first build is a GUI foundation. The Visuals entries are UI toggles/demo placeholders, not finished world-rendering features. It does not implement combat automation or bypass server rules.

## Requirements
- JDK 21
- Gradle 8.x (or open/import the project in IntelliJ IDEA and let Gradle sync)
- Minecraft 1.21.4 Fabric development environment

Fabric's 1.21.4 documentation specifies JDK 21. See:
https://github.com/FabricMC/fabric-docs/blob/main/versions/1.21.4/develop/getting-started/setting-up-a-development-environment.md

## Build
From this project folder:
```bash
gradle build
```
The output JAR will be in `build/libs/` (use the non-`-sources` JAR).

## Install
Put the built `venusmobile-1.0.0.jar` in the `mods` folder of a Minecraft 1.21.4 Fabric profile that also has Fabric API installed.

For PojavLauncher, use a compatible 1.21.4 Fabric profile and the same mod JAR. Device/renderer compatibility varies, so test first in a copied game instance.

## Next development steps
1. Test the GUI on Windows.
2. Test the same JAR in PojavLauncher.
3. Add the actual FPS/coordinates HUD.
4. Implement safe client-side visual overlays and persistent config storage.
5. Build a separate launcher only after the mod is stable.
